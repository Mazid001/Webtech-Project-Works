<?php include "../include/headerL.php"; ?>
<?php include "../sidebar/admin_sidebar.php"; ?>
			<?php include "../database/allteachers.php"; ?>
