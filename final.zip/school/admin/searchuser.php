<?php include "../include/headerL.php"; ?>
<?php include "../sidebar/admin_sidebar.php"; ?>
			
<center>Search : <input type="text" name="ids" value="" id="idvalue" />
			<input type='button' name='' value='Submit' onclick='searching()' /><br/><br/></center>
			
			
			<?php include "../database/searchbyid.php"; ?>
			
			
