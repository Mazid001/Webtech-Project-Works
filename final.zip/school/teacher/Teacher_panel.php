<?php include "../include/headerL.php"; ?>
<?php include "../sidebar/teacher_sidebar.php"; ?>
			<h1>Welcome <?php echo $_SESSION["name"]; ?></h1>
